from flask import Flask, request, render_template, jsonify, send_from_directory
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Email configuration (update with your SMTP settings)
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SENDER_EMAIL = 'your-email@gmail.com'  # Replace with your email
SENDER_PASSWORD = 'your-app-password'  # Replace with your app password

@app.route('/index.html')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/team.html')
def team():
    return send_from_directory('.', 'team.html')

@app.route('/games.html')
def games():
    return send_from_directory('.', 'games.html')

@app.route('/gallery.html')
def gallery():
    return send_from_directory('.', 'gallery.html')

@app.route('/social.html')
def social():
    return send_from_directory('.', 'social.html')

@app.route('/contact.html')
def contact():
    return send_from_directory('.', 'contact.html')

@app.route('/css/<path:filename>')
def css_files(filename):
    return send_from_directory('css', filename)

@app.route('/js/<path:filename>')
def js_files(filename):
    return send_from_directory('js', filename)

@app.route('/images/<path:filename>')
def images(filename):
    return send_from_directory('images', filename)

@app.route('/api/contact', methods=['POST'])
def contact_api():
    try:
        data = request.get_json()
        email = data.get('email')
        message = data.get('message')
        
        if not email or not message:
            return jsonify({'error': 'Email and message are required'}), 400
        
        # Send email
        msg = MIMEMultipart()
        msg['From'] = SENDER_EMAIL
        msg['To'] = SENDER_EMAIL  # Send to yourself or team email
        msg['Subject'] = f"Team X Contact Form: {email}"
        
        body = f"New message from {email}:\n\n{message}"
        msg.attach(MimeText(body, 'plain')) # type: ignore
        
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)
        server.quit()
        
        logger.info(f"Contact form submitted from {email}")
        return jsonify({'success': 'Message sent successfully'}), 200
        
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return jsonify({'error': 'Failed to send message'}), 500

@app.route('/health')
def health():
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    # Serve static files in development
    app.static_folder = '.'
    app.run(debug=True, host='0.0.0.0', port=5000)
